"""Platform service implementations."""
